package com.shee.procam;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.OutputStream;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int REQ_PERM = 1;
    private static final int REQ_FILE = 2;
    private WebView web;
    private PermissionRequest pending;
    private ValueCallback<Uri[]> fileCb;
    private OutputStream out;
    private Uri outUri;

    private boolean granted(String p) {
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private void answer(PermissionRequest r) {
        ArrayList<String> ok = new ArrayList<>();
        for (String res : r.getResources()) {
            if (res.equals(PermissionRequest.RESOURCE_VIDEO_CAPTURE) && granted(Manifest.permission.CAMERA)) ok.add(res);
            if (res.equals(PermissionRequest.RESOURCE_AUDIO_CAPTURE) && granted(Manifest.permission.RECORD_AUDIO)) ok.add(res);
        }
        if (ok.isEmpty()) r.deny(); else r.grant(ok.toArray(new String[0]));
    }

    private void toast(final String msg) {
        runOnUiThread(new Runnable() {
            public void run() { Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show(); }
        });
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#0B0B0D"));
        getWindow().setNavigationBarColor(Color.parseColor("#0B0B0D"));
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (!granted(Manifest.permission.CAMERA) || !granted(Manifest.permission.RECORD_AUDIO)) {
            requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}, REQ_PERM);
        }

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        web.addJavascriptInterface(new Bridge(), "Android");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest r) {
                runOnUiThread(new Runnable() {
                    public void run() {
                        if (granted(Manifest.permission.CAMERA)) {
                            answer(r);
                        } else {
                            pending = r;
                            requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}, REQ_PERM);
                        }
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });

        web.setDownloadListener(new android.webkit.DownloadListener() {
            @Override
            public void onDownloadStart(String url, String ua, String cd, String mime, long len) {
                if (!url.startsWith("blob:")) return;
                String m = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
                String js = "(async()=>{try{const b=await (await fetch('" + url + "')).blob();Android.begin(b.type||'" + m + "');"
                        + "const n=1<<20;for(let o=0;o<b.size;o+=n){const u=new Uint8Array(await b.slice(o,o+n).arrayBuffer());"
                        + "let s='';for(let i=0;i<u.length;i+=32768)s+=String.fromCharCode.apply(null,u.subarray(i,i+32768));Android.chunk(btoa(s))}"
                        + "Android.finish()}catch(e){Android.fail(String(e))}})()";
                web.evaluateJavascript(js, null);
            }
        });

        setContentView(web);
        web.loadUrl("https://appassets.androidplatform.net/assets/www/index.html");
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (pending != null) {
            answer(pending);
            pending = null;
            web.reload();
        }
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent d) {
        super.onActivityResult(rq, rs, d);
        if (rq == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d));
            fileCb = null;
        }
    }

    private class Bridge {
        @JavascriptInterface
        public synchronized void begin(String mime) {
            try {
                if (mime == null) mime = "image/jpeg";
                int sc = mime.indexOf(';');
                if (sc > 0) mime = mime.substring(0, sc);
                ContentValues v = new ContentValues();
                Uri coll;
                String ext;
                if (mime.startsWith("video")) {
                    coll = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                    ext = mime.contains("webm") ? "webm" : "mp4";
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/Shee Pro Cam");
                } else {
                    coll = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                    ext = mime.contains("png") ? "png" : "jpg";
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/Shee Pro Cam");
                }
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, "shee_" + System.currentTimeMillis() + "." + ext);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                outUri = getContentResolver().insert(coll, v);
                out = getContentResolver().openOutputStream(outUri);
            } catch (Exception e) {
                out = null;
                toast("Could not save: " + e.getMessage());
            }
        }

        @JavascriptInterface
        public synchronized void chunk(String b64) {
            try {
                if (out != null) out.write(Base64.decode(b64, Base64.DEFAULT));
            } catch (Exception e) {
                toast("Save error: " + e.getMessage());
            }
        }

        @JavascriptInterface
        public synchronized void finish() {
            try {
                if (out != null) {
                    out.close();
                    ContentValues u = new ContentValues();
                    u.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    getContentResolver().update(outUri, u, null, null);
                    toast("Saved to your Gallery");
                }
            } catch (Exception e) {
                toast("Save error: " + e.getMessage());
            }
            out = null;
        }

        @JavascriptInterface
        public synchronized void fail(String msg) {
            try {
                if (out != null) out.close();
                if (outUri != null) getContentResolver().delete(outUri, null, null);
            } catch (Exception e) { }
            out = null;
            toast("Save failed");
        }
    }
}
